<!DOCTYPE html>
<html>
<head>
    <title>Registro de Conta Bancária</title>
</head>
<body>
    <h2>Registro de Conta Bancária</h2>
    <form method="post" action="">
        <label for="nome">Nome do Cliente:</label>
        <input type="text" id="nome" name="nome" required><br>

        <label for="data_nascimento">Data de Nascimento:</label>
        <input type="date" id="data_nascimento" name="data_nascimento" required><br>

        <label for="endereco">Endereço:</label>
        <input type="text" id="endereco" name="endereco" required><br>

        <label for="numero_conta">Número da Conta:</label>
        <input type="text" id="numero_conta" name="numero_conta" required><br>

        <label for="tipo_conta">Tipo de Conta:</label>
        <select id="tipo_conta" name="tipo_conta">
            <option value="poupanca">Poupança</option>
            <option value="corrente">Corrente</option>
        </select><br>

        <label for="saldo_inicial">Saldo Inicial:</label>
        <input type="number" id="saldo_inicial" name="saldo_inicial" step="0.01" required><br>

        <label for="limite">Limite:</label>
        <input type="number" id="limite" name="limite" step="0.01" required><br>

        <input type="submit" name="submit" value="Registrar Conta">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nome = $_POST['nome'];
        $data_nascimento = $_POST['data_nascimento'];
        $endereco = $_POST['endereco'];
        $numero_conta = $_POST['numero_conta'];
        $tipo_conta = $_POST['tipo_conta'];
        $saldo_inicial = $_POST['saldo_inicial'];
        $limite = $_POST['limite'];

        echo "<h2>Informações da Conta Bancária Registrada:</h2>";
        echo "Nome do Cliente: $nome<br>";
        echo "Data de Nascimento: $data_nascimento<br>";
        echo "Endereço: $endereco<br>";
        echo "Número da Conta: $numero_conta<br>";
        echo "Tipo de Conta: $tipo_conta<br>";
        echo "Saldo Inicial: $saldo_inicial<br>";
        echo "Limite: $limite<br>";
    }
    ?>
</body>
</html>
