<?php
for ($num1 = 1; $num1 <= 10; $num1++) {
	for ($num2 = 1; $num2 <= 10; $num2++) {
		echo "$num1 * $num2 = " . $num1 * $num2 . "<br>";
	}
	echo "<br>";
}
?>