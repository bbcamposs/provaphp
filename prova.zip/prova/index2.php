<!DOCTYPE html>
<html>
<head>
    <title>Aceitação de idade</title>
</head>
<body>
    <form method="post" action="">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br>

        <label for="sexo">Sexo:</label>
        <input type="radio" id="sexo_feminino" name="sexo" value="Feminino" required>
        <label for="sexo_feminino">Feminino</label>
        <input type="radio" id="sexo_masculino" name="sexo" value="Masculino" required>
        <label for="sexo_masculino">Masculino</label><br>

        <label for="idade">Idade:</label>
        <input type="number" id="idade" name="idade" required><br>

        <input type="submit" name="submit" value="Verificar">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nome = $_POST['nome'];
        $sexo = $_POST['sexo'];
        $idade = $_POST['idade'];

        if ($sexo == 'Feminino' && $idade < 25) {
            echo "Nome: $nome<br>";
            echo "Mensagem: Aceita";
        } else {
            echo "Nome: $nome<br>";
            echo "Mensagem: Não aceita";
        }
    }
    ?>
</body>
</html>
